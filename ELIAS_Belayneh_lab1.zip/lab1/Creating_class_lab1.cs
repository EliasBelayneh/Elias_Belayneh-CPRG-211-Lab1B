﻿using System;
using System.Collections.Generic;
using System.Linq; 

namespace CreatingClassesLab
{
    class Person
    {
        public int PersonId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string FavoriteColour { get; set; }
        public int Age { get; set; }
        public bool IsWorking { get; set; }

        public Person(int personId, string firstName, string lastName, string favoriteColour, int age, bool isWorking)
        {
            PersonId = personId;
            FirstName = firstName;
            LastName = lastName;
            FavoriteColour = favoriteColour;
            Age = age;
            IsWorking = isWorking;
        }

        public void DisplayPersonInfo()
        {
            Console.WriteLine($"{PersonId}: {FirstName} {LastName}'s favorite colour is {FavoriteColour}");
        }

        public void ChangeFavoriteColour(string newColour)
        {
            FavoriteColour = newColour;
        }

        public int GetAgeInTenYears()
        {
            return Age + 10;
        }

        public override string ToString()
        {
            return $"PersonId: {PersonId}\n" +
                   $"FirstName: {FirstName}\n" +
                   $"LastName: {LastName}\n" +
                   $"FavoriteColour: {FavoriteColour}\n" +
                   $"Age: {Age}\n" +
                   $"IsWorking: {IsWorking}";
        }
    }

    class Relation
    {
        public string RelationshipType { get; set; }

        public Relation(string relationshipType)
        {
            RelationshipType = relationshipType;
        }

        public void ShowRelationShip(Person person1, Person person2)
        {
            Console.WriteLine($"Relationship between {person1.FirstName} and {person2.FirstName} is: {RelationshipType}");
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            Person ian = new Person(1, "Ian", "Brooks", "Red", 30, true);
            Person gina = new Person(2, "Gina", "James", "Green", 18, false);
            Person mike = new Person(3, "Mike", "Briscoe", "Blue", 45, true);
            Person mary = new Person(4, "Mary", "Beals", "Yellow", 28, true);

            Console.WriteLine("--- Initial Person Information and Operations ---");

            gina.DisplayPersonInfo();

            Console.WriteLine(mike.ToString());

            ian.ChangeFavoriteColour("White");
            ian.DisplayPersonInfo();

            Console.WriteLine($"Mary Beals’s Age in 10 years is: {mary.GetAgeInTenYears()}");

            Relation sisterhood = new Relation("Sisterhood");
            sisterhood.ShowRelationShip(gina, mary);

            Relation brotherhood = new Relation("Brotherhood");
            brotherhood.ShowRelationShip(ian, mike);

            Console.WriteLine("\n--- List Operations ---");

            List<Person> people = new List<Person> { ian, gina, mike, mary };

            double averageAge = people.Average(p => p.Age);
            Console.WriteLine($"Average age is: {averageAge}");

            // Fix for MinBy/MaxBy error: Using OrderBy/OrderByDescending and FirstOrDefault
            Person youngestPerson = people.OrderBy(p => p.Age).FirstOrDefault();
            Person oldestPerson = people.OrderByDescending(p => p.Age).FirstOrDefault();

            if (youngestPerson != null)
            {
                Console.WriteLine($"The youngest person is: {youngestPerson.FirstName}");
            }
            else
            {
                Console.WriteLine("Could not determine the youngest person.");
            }

            if (oldestPerson != null)
            {
                Console.WriteLine($"The oldest person is: {oldestPerson.FirstName}");
            }
            else
            {
                Console.WriteLine("Could not determine the oldest person.");
            }

            var namesStartingWithM = people.Where(p => p.FirstName.StartsWith("M")).Select(p => p.FirstName);
            Console.WriteLine("Names starting with M:");
            foreach (var name in namesStartingWithM)
            {
                Console.WriteLine($"- {name}");
            }

            Person personLikesBlue = people.FirstOrDefault(p => p.FavoriteColour == "Blue");
            if (personLikesBlue != null)
            {
                Console.WriteLine("Person who likes the color blue:");
                Console.WriteLine(personLikesBlue.ToString());
            }
            else
            {
                Console.WriteLine("No person found who likes the color blue.");
            }
        }
    }
}